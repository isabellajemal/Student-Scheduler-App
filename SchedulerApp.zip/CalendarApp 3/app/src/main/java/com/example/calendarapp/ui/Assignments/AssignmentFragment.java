package com.example.calendarapp.ui.Assignments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.calendarapp.R;  // Add this import statement
import com.example.calendarapp.databinding.FragmentAssignmentsBinding;
import com.example.calendarapp.ui.ToDoList.ClassListAdapter;  // Add this import statement


public class AssignmentFragment extends Fragment {



    public class AssignmentsFragment extends Fragment {

        private FragmentAssignmentsBinding binding;
        private AssignmentViewModel assignmentViewModel;
        private ClassListAdapter classListAdapter;

        public View onCreateView(@NonNull LayoutInflater inflater,
                                 ViewGroup container, Bundle savedInstanceState) {
            assignmentViewModel = new ViewModelProvider(this).get(AssignmentViewModel.class);
            binding = FragmentAssignmentsBinding.inflate(inflater, container, false);
            View root = binding.getRoot();

            // Initialize views
            EditText editTextCourseName = root.findViewById(R.id.editTextCourseName);
            EditText editTextTime = root.findViewById(R.id.editTextTime);
            EditText editTextInstructor = root.findViewById(R.id.editTextInstructor);
            Button addButton = root.findViewById(R.id.addButton);
            ListView listViewClasses = root.findViewById(R.id.listViewClasses);

            // Set up adapter for the ListView
            classListAdapter = new ClassListAdapter(requireContext(), assignmentViewModel.getClassList().getValue());
            listViewClasses.setAdapter(classListAdapter);

            // Set up add button click listener
            addButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String courseName = editTextCourseName.getText().toString();
                    String time = editTextTime.getText().toString();
                    String instructor = editTextInstructor.getText().toString();

                    if (!courseName.isEmpty() && !time.isEmpty() && !instructor.isEmpty()) {
                        assignmentViewModel.addClass(new ClassDetails(courseName, time, instructor));
                        classListAdapter.notifyDataSetChanged();
                        clearInputFields();
                    } else {
                        Toast.makeText(requireContext(), "All fields are required", Toast.LENGTH_SHORT).show();
                    }
                }
            });

            return root;
        }

        private void clearInputFields() {
            EditText editTextCourseName = binding.editTextCourseName;
            EditText editTextTime = binding.editTextTime;
            EditText editTextInstructor = binding.editTextInstructor;

            editTextCourseName.getText().clear();
            editTextTime.getText().clear();
            editTextInstructor.getText().clear();
        }

        @Override
        public void onDestroyView() {
            super.onDestroyView();
            binding = null;
        }
    }
}
