package com.example.calendarapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import com.example.calendarapp.ui.CustomAdapter;

import androidx.appcompat.app.AppCompatActivity;

import com.example.calendarapp.databinding.ActivityMainBinding;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    private EditText editText;
    private ListView listView;
    private CustomAdapter customAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);

            //editText = findViewById(R.id.editText);

            //ArrayList<String> itemList = new ArrayList<>();
            //customAdapter = new CustomAdapter(itemList);
            //listView.setAdapter(customAdapter);
        }
    }