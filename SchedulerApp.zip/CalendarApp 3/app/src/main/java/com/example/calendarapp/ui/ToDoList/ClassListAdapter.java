package com.example.calendarapp.ui.ToDoList;
// com.example.calendarapp.ui.Assignments.ClassListAdapter

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.calendarapp.R;
import com.example.calendarapp.ui.Assignments.ClassDetails;

import java.util.List;

public class ClassListAdapter extends ArrayAdapter<ClassDetails> {

    private List<ClassDetails> classList;

    public ClassListAdapter(@NonNull Context context, @NonNull List<ClassDetails> classList) {
        super(context, 0, classList);
        this.classList = classList;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.item_class, parent, false);
        }

        ClassDetails currentClass = getItem(position);

        TextView textViewCourseName = convertView.findViewById(R.id.editTextCourseName);
        TextView textViewTime = convertView.findViewById(R.id.editTextTime);
        return convertView;
    }
}


